# Farhod & Shirin — Wedding Invitation

GitHub Pages uchun tayyor elektron to'y taklifnomasi.

## Fayllar

- `index.html` — sayt tuzilishi
- `style.css` — dizayn va animatsiyalar
- `script.js` — konvert, musiqa, countdown, galereya
- `assets/` — rasmlar va musiqa

## GitHub Pages'ga joylash

1. GitHub'da yangi repository yarating, masalan: `farhod-shirin-wedding`
2. Ushbu papkadagi barcha fayllarni repository'ga yuklang.
3. `Settings` → `Pages` ga kiring.
4. `Deploy from a branch` ni tanlang.
5. Branch: `main`, folder: `/ (root)` → `Save`.
6. GitHub sizga sayt manzilini beradi.

## Rasmlarni almashtirish

Yangi rasmlarni `assets` papkasiga qo'ying va `index.html` ichidagi fayl nomlarini moslang.

## Musiqani almashtirish

Musiqa faylini `assets/wedding-music.mp3` nomida saqlang.

Brauzer qoidalari sabab musiqa visitor `Taklifnomani ochish` tugmasini bosgandan keyin ishga tushadi.

## Ma'lumotlarni almashtirish

`index.html` ichidagi:
- Farhod & Shirin
- 1 Noyabr 2026
- 16:00
- «Abu-Dabi» restorani
- Osh shahri
- Sarvar Gulzoda

matnlarini boshqa to'y uchun almashtirish mumkin.

`script.js` ichidagi `weddingDate` esa countdown sanasini boshqaradi.
